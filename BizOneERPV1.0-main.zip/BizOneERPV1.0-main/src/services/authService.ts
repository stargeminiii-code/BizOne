import { UserAccount, UserRole, UserSession, SystemAuditEntry } from '../types';
import { INITIAL_USERS, ROLE_DEFINITIONS } from '../data/userData';
import { INITIAL_SYSTEM_AUDIT_LOGS } from '../data/infrastructureData';

const USERS_STORAGE_KEY = 'wiup_users_db_v2';
const CURRENT_SESSION_KEY = 'wiup_active_session_user_v2';
const TOKEN_STORAGE_KEY = 'wiup_auth_token_v2';
const AUDIT_LOGS_STORAGE_KEY = 'wiup_audit_logs_v2';
const CUSTOM_ROLES_STORAGE_KEY = 'wiup_custom_roles_v2';

export interface CustomRoleDefinition {
  id: string;
  key: string;
  name: string;
  description: string;
  badgeColor: string;
  isSystemDefault: boolean;
  permissions: UserAccount['permissions'];
  createdAt: string;
  createdBy: string;
}

export interface SessionTokenPayload {
  uid: string;
  sub: string;
  email: string;
  role: UserRole;
  tenant: 'enterprise' | 'demo';
  scope: string;
  sid: string;
  iat: number;
  exp: number;
}

export const INITIAL_CUSTOM_ROLES: CustomRoleDefinition[] = Object.entries(ROLE_DEFINITIONS).map(
  ([key, def]) => ({
    id: `role-${key}`,
    key,
    name: def.name,
    description: def.description,
    badgeColor: def.badgeColor,
    isSystemDefault: true,
    permissions: def.defaultPermissions,
    createdAt: '2026-01-01 00:00',
    createdBy: 'Hệ thống'
  })
);

export class AuthService {
  // Normalize phone numbers for robust matching (+84, 84, 0, spaces, dashes)
  static normalizePhone(raw: string): string {
    const digits = raw.replace(/\D/g, '');
    if (digits.startsWith('84') && digits.length >= 10) {
      return '0' + digits.slice(2);
    }
    return digits;
  }

  // Parse and verify token validity & expiration from client perspective
  static verifyToken(token: string): { valid: boolean; payload?: SessionTokenPayload; error?: string } {
    if (!token || (!token.startsWith('bizone_jwt.') && !token.startsWith('wiup_jwt.'))) {
      return { valid: false, error: 'Token không đúng định dạng BizOne ERP' };
    }

    try {
      const cleanToken = token.startsWith('bizone_jwt.') ? token.replace('bizone_jwt.', '') : token.replace('wiup_jwt.', '');
      const parts = cleanToken.split('.');
      if (parts.length !== 3) {
        return { valid: false, error: 'Cấu trúc Token không hợp lệ' };
      }

      const payloadJson = decodeURIComponent(escape(atob(parts[1])));
      const payload: SessionTokenPayload = JSON.parse(payloadJson);

      const now = Date.now();
      if (payload.exp && now > payload.exp) {
        return { valid: false, error: 'Phiên đăng nhập (Session Token) đã hết hạn. Vui lòng đăng nhập lại.' };
      }

      return { valid: true, payload };
    } catch (e) {
      return { valid: false, error: 'Không thể giải mã Session Token' };
    }
  }

  // Get active session token from LocalStorage (supports both modern and standard keys)
  static getActiveToken(): string | null {
    try {
      return localStorage.getItem(TOKEN_STORAGE_KEY) || localStorage.getItem('bizone_jwt') || null;
    } catch (e) {
      return null;
    }
  }

  // Set active session token
  static setSessionToken(token: string | null): void {
    try {
      if (token) {
        localStorage.setItem(TOKEN_STORAGE_KEY, token);
        localStorage.setItem('bizone_jwt', token);
      } else {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        localStorage.removeItem('bizone_jwt');
      }
    } catch (e) {
      console.error('Could not save session token', e);
    }
  }

  // Get all users from storage or fallback to defaults
  static getUsers(): UserAccount[] {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read users from localStorage', e);
    }

    AuthService.saveUsers(INITIAL_USERS);
    return INITIAL_USERS;
  }

  // Save users list to localStorage
  static saveUsers(users: UserAccount[]): void {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.error('Could not save users to localStorage', e);
    }
  }

  // Get active session user with token verification
  static getCurrentUser(): UserAccount | null {
    try {
      const token = AuthService.getActiveToken();
      if (token) {
        const verification = AuthService.verifyToken(token);
        if (!verification.valid) {
          AuthService.clearSession();
          return null;
        }
      }

      const stored = localStorage.getItem(CURRENT_SESSION_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.id) {
          const users = AuthService.getUsers();
          const fresh = users.find((u) => u.id === parsed.id);
          if (fresh && fresh.status !== 'locked' && fresh.status !== 'inactive') {
            return fresh;
          }
          if (parsed && parsed.status !== 'locked' && parsed.status !== 'inactive') {
            return parsed;
          }
        }
      }
    } catch (e) {
      console.warn('Could not parse active session', e);
    }
    return null;
  }

  // Set active session user
  static setCurrentUser(user: UserAccount | null): void {
    try {
      if (user) {
        localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(CURRENT_SESSION_KEY);
      }
    } catch (e) {
      console.error('Could not set current session', e);
    }
  }

  // Clear all session artifacts
  static clearSession(): void {
    try {
      localStorage.removeItem(CURRENT_SESSION_KEY);
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    } catch (e) {
      console.error('Could not clear session', e);
    }
  }

  // Verify Current Session Status (client verification + backend verification if possible)
  static verifyCurrentSession(): { isAuthenticated: boolean; user: UserAccount | null; token: string | null } {
    const token = AuthService.getActiveToken();
    if (!token) {
      return { isAuthenticated: false, user: null, token: null };
    }

    const tokenVerification = AuthService.verifyToken(token);
    if (!tokenVerification.valid) {
      AuthService.clearSession();
      return { isAuthenticated: false, user: null, token: null };
    }

    const user = AuthService.getCurrentUser();
    if (!user) {
      return { isAuthenticated: false, user: null, token: null };
    }

    return { isAuthenticated: true, user, token };
  }

  /**
   * Primary Backend Authentication Endpoint Integration
   * Sends credentials to /api/auth/login where bcrypt verification,
   * tenant check, locking policy, and 2FA challenge / JWT session generation take place.
   */
  static async login(
    identifier: string,
    passwordPlain: string,
    rememberMe: boolean = true
  ): Promise<{
    success: boolean;
    user?: UserAccount;
    token?: string;
    require2FA?: boolean;
    require2FASetup?: boolean;
    tempToken?: string;
    message?: string;
    maskedEmail?: string;
    maskedPhone?: string;
    error?: string;
    errorType?: string;
    requirePasswordChange?: boolean;
  }> {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: identifier.trim(),
          password: passwordPlain.trim(),
          rememberMe
        })
      });

      const data = await response.json();

      if (response.ok && data.success && data.require2FA) {
        return {
          success: false,
          require2FA: true,
          require2FASetup: data.require2FASetup || false,
          tempToken: data.tempToken,
          message: data.message,
          maskedEmail: data.maskedEmail,
          maskedPhone: data.maskedPhone
        };
      }

      if (response.ok && data.success && data.user && data.token) {
        // Save session token and user to client storage
        AuthService.setSessionToken(data.token);
        AuthService.setCurrentUser(data.user);

        // Synchronize in local users list
        const currentUsers = AuthService.getUsers();
        const updatedUsers = currentUsers.map((u) => (u.id === data.user.id ? data.user : u));
        if (!updatedUsers.some((u) => u.id === data.user.id)) {
          updatedUsers.unshift(data.user);
        }
        AuthService.saveUsers(updatedUsers);

        return {
          success: true,
          user: data.user,
          token: data.token,
          requirePasswordChange: data.user.forcePasswordChange
        };
      }

      return {
        success: false,
        error: data.error || 'Đăng nhập không thành công. Vui lòng kiểm tra lại thông tin.',
        errorType: data.errorType
      };
    } catch (err: any) {
      console.error('Login network error:', err);
      return {
        success: false,
        error: 'Không thể kết nối đến máy chủ xác thực. Vui lòng kiểm tra kết nối mạng.'
      };
    }
  }

  /**
   * Verify 2FA TOTP code to complete login
   */
  static async verify2FALogin(
    tempToken: string,
    code: string,
    rememberMe: boolean = true
  ): Promise<{
    success: boolean;
    user?: UserAccount;
    token?: string;
    error?: string;
    errorType?: string;
  }> {
    try {
      const response = await fetch('/api/auth/2fa/verify-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tempToken,
          code: code.trim(),
          rememberMe
        })
      });

      const data = await response.json();

      if (response.ok && data.success && data.user && data.token) {
        AuthService.setSessionToken(data.token);
        AuthService.setCurrentUser(data.user);

        const currentUsers = AuthService.getUsers();
        const updatedUsers = currentUsers.map((u) => (u.id === data.user.id ? data.user : u));
        if (!updatedUsers.some((u) => u.id === data.user.id)) {
          updatedUsers.unshift(data.user);
        }
        AuthService.saveUsers(updatedUsers);

        return {
          success: true,
          user: data.user,
          token: data.token
        };
      }

      return {
        success: false,
        error: data.error || 'Mã xác thực 2FA không chính xác',
        errorType: data.errorType
      };
    } catch (err: any) {
      console.error('2FA verification error:', err);
      return {
        success: false,
        error: 'Không thể kết nối đến máy chủ xác thực 2FA'
      };
    }
  }

  /**
   * Verify 2FA Emergency Backup Recovery Code
   */
  static async verifyRecoveryCodeLogin(
    tempToken: string,
    recoveryCode: string,
    rememberMe: boolean = true
  ): Promise<{
    success: boolean;
    user?: UserAccount;
    token?: string;
    remainingRecoveryCodesCount?: number;
    error?: string;
    errorType?: string;
  }> {
    try {
      const response = await fetch('/api/auth/2fa/verify-recovery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tempToken,
          recoveryCode: recoveryCode.trim().toUpperCase(),
          rememberMe
        })
      });

      const data = await response.json();

      if (response.ok && data.success && data.user && data.token) {
        AuthService.setSessionToken(data.token);
        AuthService.setCurrentUser(data.user);

        const currentUsers = AuthService.getUsers();
        const updatedUsers = currentUsers.map((u) => (u.id === data.user.id ? data.user : u));
        AuthService.saveUsers(updatedUsers);

        return {
          success: true,
          user: data.user,
          token: data.token,
          remainingRecoveryCodesCount: data.remainingRecoveryCodesCount
        };
      }

      return {
        success: false,
        error: data.error || 'Mã khôi phục không hợp lệ hoặc đã sử dụng',
        errorType: data.errorType
      };
    } catch (err: any) {
      return {
        success: false,
        error: 'Không thể xác thực mã khôi phục dự phòng'
      };
    }
  }

  /**
   * Setup 2FA: Generates secret & QR code
   */
  static async setup2FA(tempToken?: string): Promise<{
    success: boolean;
    secret?: string;
    otpauthUrl?: string;
    qrCodeDataUrl?: string;
    username?: string;
    error?: string;
  }> {
    const token = tempToken || AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/2fa/setup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ tempToken })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        return {
          success: true,
          secret: data.secret,
          otpauthUrl: data.otpauthUrl,
          qrCodeDataUrl: data.qrCodeDataUrl,
          username: data.username
        };
      }
      return { success: false, error: data.error || 'Không thể tạo khóa 2FA' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kết nối khi thiết lập 2FA' };
    }
  }

  /**
   * Enable 2FA with verified TOTP code
   */
  static async enable2FA(
    secret: string,
    code: string,
    tempToken?: string
  ): Promise<{
    success: boolean;
    recoveryCodes?: string[];
    user?: UserAccount;
    token?: string;
    error?: string;
  }> {
    const token = tempToken || AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/2fa/enable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ secret, code, tempToken })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        if (data.token) {
          AuthService.setSessionToken(data.token);
        }
        if (data.user) {
          AuthService.setCurrentUser(data.user);
          const users = AuthService.getUsers();
          const updated = users.map((u) => (u.id === data.user.id ? data.user : u));
          AuthService.saveUsers(updated);
        }
        return {
          success: true,
          recoveryCodes: data.recoveryCodes,
          user: data.user,
          token: data.token
        };
      }
      return { success: false, error: data.error || 'Mã xác thực 2FA không chính xác' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kích hoạt 2FA' };
    }
  }

  /**
   * Disable 2FA
   */
  static async disable2FA(): Promise<{ success: boolean; error?: string }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/2fa/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        const user = AuthService.getCurrentUser();
        if (user) {
          user.twoFactorEnabled = false;
          AuthService.setCurrentUser(user);
        }
        return { success: true };
      }
      return { success: false, error: data.error || 'Không thể tắt 2FA' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi tắt 2FA' };
    }
  }

  /**
   * Change Password
   */
  static async changePassword(
    oldPasswordPlain: string,
    newPasswordPlain: string
  ): Promise<{ success: boolean; error?: string; message?: string }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          oldPassword: oldPasswordPlain,
          newPassword: newPasswordPlain
        })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Đổi mật khẩu không thành công' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kết nối đổi mật khẩu' };
    }
  }

  // Alias for backward compatibility
  static async authenticate(
    identifier: string,
    passwordPlain: string,
    rememberMe: boolean = true
  ) {
    return AuthService.login(identifier, passwordPlain, rememberMe);
  }

  // Backend session verification
  static async verifySessionWithServer(): Promise<boolean> {
    const token = AuthService.getActiveToken();
    if (!token) return false;

    try {
      const response = await fetch('/api/auth/verify-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ token })
      });

      const data = await response.json();
      if (response.ok && data.valid && data.user) {
        AuthService.setCurrentUser(data.user);
        return true;
      } else {
        AuthService.clearSession();
        return false;
      }
    } catch (e) {
      // If network offline, verify token locally
      const local = AuthService.verifyToken(token);
      return local.valid;
    }
  }

  // Logout handler with server notification and token clearance
  static async logout(user: UserAccount | null): Promise<void> {
    const token = AuthService.getActiveToken();
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        });
      } catch (e) {
        console.warn('Logout notification error:', e);
      }
    }
    AuthService.clearSession();
  }

  // Get Audit Logs
  static getAuditLogs(): SystemAuditEntry[] {
    try {
      const stored = localStorage.getItem(AUDIT_LOGS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read audit logs', e);
    }
    localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify(INITIAL_SYSTEM_AUDIT_LOGS));
    return INITIAL_SYSTEM_AUDIT_LOGS;
  }

  // Append Audit Log
  static addAuditLog(entry: Omit<SystemAuditEntry, 'id' | 'timestamp'>): void {
    try {
      const current = AuthService.getAuditLogs();
      const newEntry: SystemAuditEntry = {
        ...entry,
        id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19)
      };
      const updated = [newEntry, ...current].slice(0, 500);
      localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify(updated));

      // Asynchronously send to server if token exists
      const token = AuthService.getActiveToken();
      if (token) {
        fetch('/api/auth/audit-log', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify(newEntry)
        }).catch(() => {});
      }
    } catch (e) {
      console.error('Failed to log audit action', e);
    }
  }

  // Get Custom Roles
  static getCustomRoles(): CustomRoleDefinition[] {
    try {
      const stored = localStorage.getItem(CUSTOM_ROLES_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read custom roles', e);
    }
    localStorage.setItem(CUSTOM_ROLES_STORAGE_KEY, JSON.stringify(INITIAL_CUSTOM_ROLES));
    return INITIAL_CUSTOM_ROLES;
  }

  // Save Custom Roles
  static saveCustomRoles(roles: CustomRoleDefinition[]): void {
    try {
      localStorage.setItem(CUSTOM_ROLES_STORAGE_KEY, JSON.stringify(roles));
    } catch (e) {
      console.error('Could not save custom roles', e);
    }
  }

  /**
   * Request Password Reset OTP via Email and SMS
   */
  static async requestPasswordReset(identifier: string): Promise<{
    success: boolean;
    challengeId?: string;
    maskedEmail?: string;
    maskedPhone?: string;
    message?: string;
    error?: string;
    errorType?: string;
  }> {
    try {
      const response = await fetch('/api/auth/password-reset/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: identifier.trim() })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        return {
          success: true,
          challengeId: data.challengeId,
          maskedEmail: data.maskedEmail,
          maskedPhone: data.maskedPhone,
          message: data.message
        };
      }
      return {
        success: false,
        error: data.error || 'Không thể xử lý yêu cầu đặt lại mật khẩu.',
        errorType: data.errorType
      };
    } catch (e: any) {
      return {
        success: false,
        error: 'Lỗi kết nối máy chủ khi gửi yêu cầu đặt lại mật khẩu.'
      };
    }
  }

  /**
   * Verify Password Reset 6-Digit OTP
   */
  static async verifyPasswordResetOtp(
    challengeId: string,
    otp: string
  ): Promise<{
    success: boolean;
    resetToken?: string;
    message?: string;
    error?: string;
    errorType?: string;
  }> {
    try {
      const response = await fetch('/api/auth/password-reset/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          challengeId,
          otp: otp.trim()
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        return {
          success: true,
          resetToken: data.resetToken,
          message: data.message
        };
      }
      return {
        success: false,
        error: data.error || 'Mã OTP không chính xác hoặc đã hết hạn.',
        errorType: data.errorType
      };
    } catch (e: any) {
      return {
        success: false,
        error: 'Lỗi kết nối máy chủ khi xác minh OTP.'
      };
    }
  }

  /**
   * Complete Password Reset with New Password
   */
  static async completePasswordReset(
    resetToken: string,
    newPasswordPlain: string
  ): Promise<{
    success: boolean;
    message?: string;
    error?: string;
    errorType?: string;
  }> {
    try {
      const response = await fetch('/api/auth/password-reset/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resetToken,
          newPassword: newPasswordPlain
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        return {
          success: true,
          message: data.message
        };
      }
      return {
        success: false,
        error: data.error || 'Không thể hoàn tất đặt lại mật khẩu.',
        errorType: data.errorType
      };
    } catch (e: any) {
      return {
        success: false,
        error: 'Lỗi kết nối máy chủ khi thiết lập mật khẩu mới.'
      };
    }
  }

  // Admin lock/unlock user via backend API
  static async toggleLockUser(
    targetUserId: string,
    performer: UserAccount
  ): Promise<{ success: boolean; message: string; updatedUser?: UserAccount }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/toggle-lock', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        // Sync local users
        const users = AuthService.getUsers();
        const updated = users.map((u) => (u.id === targetUserId ? data.updatedUser : u));
        AuthService.saveUsers(updated);
        return { success: true, message: data.message, updatedUser: data.updatedUser };
      }
      return { success: false, message: data.error || 'Thao tác không thành công.' };
    } catch (e: any) {
      return { success: false, message: e.message || 'Lỗi kết nối máy chủ.' };
    }
  }

  // Admin reset password for user with Bcrypt hashing via backend API
  static async resetPassword(
    targetUserId: string,
    newPasswordPlain: string,
    requireChangeNextLogin: boolean,
    performer: UserAccount
  ): Promise<{ success: boolean; message: string }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          targetUserId,
          newPassword: newPasswordPlain,
          requireChangeNextLogin
        })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, message: data.message };
      }
      return { success: false, message: data.error || 'Không thể đặt lại mật khẩu.' };
    } catch (e: any) {
      return { success: false, message: e.message || 'Lỗi kết nối máy chủ.' };
    }
  }

  /**
   * Admin / Tenant Admin initiates secure password reset challenge for user (POST /api/users/:id/password-reset/request)
   */
  static async requestAdminPasswordReset(targetUserId: string): Promise<{
    success: boolean;
    challengeId?: string;
    maskedEmail?: string;
    maskedPhone?: string;
    message?: string;
    error?: string;
    errorType?: string;
  }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch(`/api/users/${targetUserId}/password-reset/request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return {
          success: true,
          challengeId: data.challengeId,
          maskedEmail: data.maskedEmail,
          maskedPhone: data.maskedPhone,
          message: data.message
        };
      }
      return {
        success: false,
        error: data.error || 'Không thể gửi yêu cầu đặt lại mật khẩu cho nhân sự.',
        errorType: data.errorType
      };
    } catch (e: any) {
      return {
        success: false,
        error: 'Lỗi kết nối máy chủ khi khởi tạo đặt lại mật khẩu.'
      };
    }
  }

  /**
   * Get Active Sessions for Current User (GET /api/auth/sessions)
   */
  static async getActiveSessions(): Promise<{
    success: boolean;
    sessions?: Array<{ id: string; ipMasked: string; device: string; loginAt: string; isCurrent: boolean }>;
    error?: string;
  }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/sessions', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, sessions: data.sessions };
      }
      return { success: false, error: data.error || 'Không thể lấy danh sách phiên.' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kết nối khi tải danh sách phiên.' };
    }
  }

  /**
   * Revoke Specific Session (POST /api/auth/sessions/revoke)
   */
  static async revokeSession(sessionId: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/sessions/revoke', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ sessionId })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Không thể thu hồi phiên.' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kết nối khi thu hồi phiên.' };
    }
  }

  /**
   * Revoke All Other Sessions (POST /api/auth/sessions/revoke)
   */
  static async revokeAllOtherSessions(): Promise<{ success: boolean; message?: string; error?: string }> {
    const token = AuthService.getActiveToken();
    try {
      const response = await fetch('/api/auth/sessions/revoke', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ revokeAllOther: true })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true, message: data.message };
      }
      return { success: false, error: data.error || 'Không thể thu hồi các phiên khác.' };
    } catch (e: any) {
      return { success: false, error: 'Lỗi kết nối khi thu hồi các phiên.' };
    }
  }
}
